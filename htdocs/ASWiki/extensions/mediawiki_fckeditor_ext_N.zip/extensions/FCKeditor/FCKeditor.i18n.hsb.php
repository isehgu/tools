<?php

$messages = array(
	'textrichditor' => 'Rich editor',
	'tog-riched_disable' => 'Rich editor deaktiwizować',
	'tog-riched_disable_ns_main' => 'Rich editor znutřka hłowneho mjenoweho ruma deaktiwizować',
	'tog-riched_disable_ns_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:Talk}}" deaktiwizować',
	'tog-riched_disable_ns_user' => 'Rich editor znutřka mjenoweho ruma "{{ns:User}}" deaktiwizować',
	'tog-riched_disable_ns_user_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:User_talk}}" deaktiwizować',
	'tog-riched_disable_ns_project' => 'Rich editor znutřka mjenoweho ruma "{{ns:Project}}" deaktiwizować',
	'tog-riched_disable_ns_project_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:Project_talk}}" deaktiwizować',
	'tog-riched_disable_ns_image' => 'Rich editor znutřka mjenoweho ruma "{{ns:Image}}" deaktiwizować',
	'tog-riched_disable_ns_image_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:Image_talk}}" deaktiwizować',
	'tog-riched_disable_ns_mediawiki' => 'Rich editor znutřka mjenoweho ruma "{{ns:MediaWiki}}" deaktiwizować',
	'tog-riched_disable_ns_mediawiki_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:MediaWiki_talk}}" deaktiwizować',
	'tog-riched_disable_ns_template' => 'Rich editor znutřka mjenoweho ruma "{{ns:Template}}" deaktiwizować',
	'tog-riched_disable_ns_template_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:Template_talk}}" deaktiwizować',
	'tog-riched_disable_ns_help' => 'Rich editor znutřka mjenoweho ruma "{{ns:Help}}" deaktiwizować',
	'tog-riched_disable_ns_help_talk' => 'Rich editor znutřka mjenoweho ruma "{{ns:Help_talk}}" deaktiwizować',
	'tog-riched_disable_ns_category' => 'Rich editor znutřka mjenoweho ruma the "{{ns:Category}}" deaktiwizować',
	'tog-riched_disable_ns_category_talk' => 'Rich editor znutřka mjenoweho ruma the "{{ns:Category_talk}}" deaktiwizować',
);
