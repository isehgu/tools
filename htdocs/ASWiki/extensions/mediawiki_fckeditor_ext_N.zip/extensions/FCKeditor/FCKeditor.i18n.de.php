<?php

$messages = array(
'textrichditor' => 'Rich Editor',
'tog-riched_disable' => 'Rich editor deaktivieren',
'tog-riched_disable_ns_main' => 'Rich editor deaktivieren im Haupt-Namensraum',
'tog-riched_disable_ns_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Talk}}" ',
'tog-riched_disable_ns_user' => 'Rich editor deaktivieren im Namensraum "{{ns:User}}" ',
'tog-riched_disable_ns_user_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:User_talk}}" ',
'tog-riched_disable_ns_project' => 'Rich editor deaktivieren im Namensraum "{{ns:Project}}" ',
'tog-riched_disable_ns_project_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Project_talk}}" ',
'tog-riched_disable_ns_image' => 'Rich editor deaktivieren im Namensraum "{{ns:Image}}" ',
'tog-riched_disable_ns_image_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Image_talk}}" ',
'tog-riched_disable_ns_mediawiki' => 'Rich editor deaktivieren im Namensraum "{{ns:MediaWiki}}" ',
'tog-riched_disable_ns_mediawiki_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:MediaWiki_talk}}" ',
'tog-riched_disable_ns_template' => 'Rich editor deaktivieren im Namensraum "{{ns:Template}}" ',
'tog-riched_disable_ns_template_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Template_talk}}" ',
'tog-riched_disable_ns_help' => 'Rich editor deaktivieren im Namensraum "{{ns:Help}}" ',
'tog-riched_disable_ns_help_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Help_talk}}" ',
'tog-riched_disable_ns_category' => 'Rich editor deaktivieren im Namensraum "{{ns:Category}}" ',
'tog-riched_disable_ns_category_talk' => 'Rich editor deaktivieren im Namensraum "{{ns:Category_talk}}" ',
);
